'use client'
import { useState, useEffect, useCallback, useRef } from 'react'
import { OverviewData, BudgetItem } from '@/lib/types'

export interface DashboardState {
  data: (OverviewData & { budget: BudgetItem[] }) | null
  loading: boolean
  error: string | null
  lastUpdated: Date | null
  paused: boolean
  refresh: () => void
  togglePause: () => void
}

const INTERVAL = parseInt(process.env.NEXT_PUBLIC_REFRESH_MS || '30000')

export function useDashboard(): DashboardState {
  const [data, setData]           = useState<DashboardState['data']>(null)
  const [loading, setLoading]     = useState(true)
  const [error, setError]         = useState<string | null>(null)
  const [lastUpdated, setLast]    = useState<Date | null>(null)
  const [paused, setPaused]       = useState(false)
  const timerRef                  = useRef<NodeJS.Timeout>()
  const pausedRef                 = useRef(false)

  pausedRef.current = paused

  const fetch_ = useCallback(async () => {
    if (pausedRef.current) return
    try {
      const res  = await fetch('/api/overview')
      const json = await res.json()
      setData(json)
      setError(null)
      setLast(new Date())
    } catch (e: any) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  const refresh = useCallback(() => {
    setLoading(true)
    fetch_()
  }, [fetch_])

  const togglePause = useCallback(() => {
    setPaused(p => !p)
  }, [])

  useEffect(() => {
    fetch_()
    timerRef.current = setInterval(fetch_, INTERVAL)
    return () => clearInterval(timerRef.current)
  }, [fetch_])

  return { data, loading, error, lastUpdated, paused, refresh, togglePause }
}
