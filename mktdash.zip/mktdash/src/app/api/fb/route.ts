import { NextResponse } from 'next/server'
import { makeDemoChannel } from '@/lib/demo'

const BASE  = 'https://graph.facebook.com/v19.0'
const TOKEN = process.env.FACEBOOK_ACCESS_TOKEN
const ACCT  = process.env.FACEBOOK_AD_ACCOUNT_ID

async function fbGet(path: string, params: Record<string, string> = {}) {
  const url = new URL(`${BASE}${path}`)
  url.searchParams.set('access_token', TOKEN!)
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v))
  const res = await fetch(url.toString(), { next: { revalidate: 25 } })
  if (!res.ok) throw new Error(`FB ${res.status}: ${await res.text()}`)
  return res.json()
}

function isConfigured() {
  return TOKEN && TOKEN !== 'your_long_lived_token_here' && ACCT && ACCT !== 'act_your_account_id_here'
}

export async function GET() {
  /* ── Demo mode ── */
  if (!isConfigured()) {
    return NextResponse.json({
      facebook:  { ...makeDemoChannel('facebook') },
      instagram: { ...makeDemoChannel('instagram') },
    })
  }

  try {
    const insightFields = 'reach,impressions,clicks,spend,actions,ctr,cpm,cpp'
    const campaignFields = `name,status,objective,daily_budget,lifetime_budget,insights{${insightFields}}`

    const [fbIns, igIns, campaigns] = await Promise.all([
      fbGet(`/${ACCT}/insights`, { fields: insightFields, date_preset: 'today', level: 'account', publisher_platforms: 'facebook' }),
      fbGet(`/${ACCT}/insights`, { fields: insightFields, date_preset: 'today', level: 'account', publisher_platforms: 'instagram' }),
      fbGet(`/${ACCT}/campaigns`, { fields: campaignFields, effective_status: '["ACTIVE","PAUSED"]', limit: '20' }),
    ])

    const parseIns = (ins: any, channel: 'facebook' | 'instagram') => {
      const d = ins?.data?.[0] || {}
      const convActions = (d.actions || []).filter((a: any) =>
        ['purchase', 'lead', 'complete_registration', 'offsite_conversion.fb_pixel_purchase'].includes(a.action_type)
      )
      const conversions = convActions.reduce((s: number, a: any) => s + parseInt(a.value || 0), 0)
      const spend = parseFloat(d.spend || 0)
      const impressions = parseInt(d.impressions || 0)
      const clicks = parseInt(d.clicks || 0)
      const reach = parseInt(d.reach || 0)
      return {
        channel,
        demo: false,
        spend,
        reach,
        impressions,
        clicks,
        ctr: parseFloat(d.ctr || 0),
        cpm: parseFloat(d.cpm || 0),
        conversions,
        roas: conversions > 0 ? parseFloat((conversions / spend).toFixed(2)) : 0,
        campaigns: (campaigns?.data || []).map((c: any) => {
          const ci = c.insights?.data?.[0] || {}
          const cs = parseFloat(ci.spend || 0)
          const ci2 = parseInt(ci.impressions || 0)
          const cc = parseInt(ci.clicks || 0)
          const cv = (ci.actions || []).reduce((s: number, a: any) => s + parseInt(a.value || 0), 0)
          return {
            id: c.id, name: c.name, channel,
            status: c.status, objective: c.objective || 'REACH',
            budget: parseInt(c.daily_budget || c.lifetime_budget || 0) / 100,
            budgetType: c.daily_budget ? 'daily' : 'lifetime',
            spend: cs, reach: parseInt(ci.reach || 0), impressions: ci2, clicks: cc,
            ctr: parseFloat(ci.ctr || 0), cpm: parseFloat(ci.cpm || 0),
            cpc: cc > 0 ? parseFloat((cs / cc).toFixed(2)) : 0,
            conversions: cv, conversionRate: cc > 0 ? parseFloat(((cv / cc) * 100).toFixed(2)) : 0,
            roas: cv > 0 ? parseFloat((cv / cs).toFixed(2)) : 0,
            startDate: new Date().toISOString().split('T')[0],
          }
        }),
        series: [],
      }
    }

    return NextResponse.json({
      facebook:  parseIns(fbIns, 'facebook'),
      instagram: parseIns(igIns, 'instagram'),
    })
  } catch (err: any) {
    console.error('[FB API]', err.message)
    return NextResponse.json({
      facebook:  { ...makeDemoChannel('facebook'),  demo: true, error: err.message },
      instagram: { ...makeDemoChannel('instagram'), demo: true, error: err.message },
    })
  }
}
