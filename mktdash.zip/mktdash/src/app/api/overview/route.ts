import { NextResponse } from 'next/server'
import { buildOverview, buildBudget } from '@/lib/demo'
import { ChannelStats } from '@/lib/types'

export async function GET(request: Request) {
  const origin = new URL(request.url).origin

  const [fbRes, gaRes, ttRes] = await Promise.allSettled([
    fetch(`${origin}/api/fb`,         { next: { revalidate: 25 } }),
    fetch(`${origin}/api/google-ads`, { next: { revalidate: 25 } }),
    fetch(`${origin}/api/tiktok`,     { next: { revalidate: 25 } }),
  ])

  const fbData  = fbRes.status  === 'fulfilled' ? await fbRes.value.json()  : null
  const gaData  = gaRes.status  === 'fulfilled' ? await gaRes.value.json()  : null
  const ttData  = ttRes.status  === 'fulfilled' ? await ttRes.value.json()  : null

  const channels: ChannelStats[] = [
    fbData?.facebook,
    fbData?.instagram,
    gaData,
    ttData,
  ].filter(Boolean)

  const overview = buildOverview(channels)
  const budget   = buildBudget(channels)

  return NextResponse.json({
    ...overview,
    budget,
    updatedAt: new Date().toISOString(),
  })
}
