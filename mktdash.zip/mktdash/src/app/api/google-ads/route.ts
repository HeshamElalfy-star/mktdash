import { NextResponse } from 'next/server'
import { makeDemoChannel } from '@/lib/demo'

const DEV_TOKEN   = process.env.GOOGLE_ADS_DEVELOPER_TOKEN
const CLIENT_ID   = process.env.GOOGLE_ADS_CLIENT_ID
const CLIENT_SEC  = process.env.GOOGLE_ADS_CLIENT_SECRET
const REFRESH_TOK = process.env.GOOGLE_ADS_REFRESH_TOKEN
const CUSTOMER_ID = process.env.GOOGLE_ADS_CUSTOMER_ID

function isConfigured() {
  return DEV_TOKEN && DEV_TOKEN !== 'your_developer_token' &&
         CUSTOMER_ID && CUSTOMER_ID !== 'your_customer_id_no_dashes'
}

async function getAccessToken(): Promise<string> {
  const res = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id: CLIENT_ID!,
      client_secret: CLIENT_SEC!,
      refresh_token: REFRESH_TOK!,
      grant_type: 'refresh_token',
    }),
  })
  const data = await res.json()
  if (!data.access_token) throw new Error('No access_token: ' + JSON.stringify(data))
  return data.access_token
}

async function gaqlQuery(accessToken: string, query: string) {
  const url = `https://googleads.googleapis.com/v16/customers/${CUSTOMER_ID}/googleAds:search`
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'developer-token': DEV_TOKEN!,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ query }),
    next: { revalidate: 25 },
  })
  if (!res.ok) throw new Error(`Google Ads ${res.status}: ${await res.text()}`)
  return res.json()
}

export async function GET() {
  if (!isConfigured()) {
    return NextResponse.json(makeDemoChannel('google_ads'))
  }

  try {
    const accessToken = await getAccessToken()

    const [accountData, campaignData] = await Promise.all([
      gaqlQuery(accessToken, `
        SELECT
          metrics.cost_micros, metrics.impressions, metrics.clicks,
          metrics.conversions, metrics.ctr, metrics.average_cpm, metrics.all_conversions_value
        FROM customer
        WHERE segments.date DURING TODAY
      `),
      gaqlQuery(accessToken, `
        SELECT
          campaign.id, campaign.name, campaign.status,
          campaign.advertising_channel_type,
          campaign_budget.amount_micros,
          metrics.cost_micros, metrics.impressions, metrics.clicks,
          metrics.conversions, metrics.ctr, metrics.average_cpm
        FROM campaign
        WHERE campaign.status IN ('ENABLED','PAUSED')
          AND segments.date DURING LAST_7_DAYS
        ORDER BY metrics.cost_micros DESC
        LIMIT 20
      `),
    ])

    const row = accountData?.results?.[0] || {}
    const m   = row.metrics || {}
    const spend       = (parseInt(m.cost_micros || 0)) / 1_000_000
    const impressions = parseInt(m.impressions || 0)
    const clicks      = parseInt(m.clicks || 0)
    const conversions = parseFloat(m.conversions || 0)
    const revenue     = parseFloat(m.all_conversions_value || 0)

    const campaigns = (campaignData?.results || []).map((r: any) => {
      const cm = r.metrics || {}
      const cs = parseInt(cm.cost_micros || 0) / 1_000_000
      const ci = parseInt(cm.impressions || 0)
      const cc = parseInt(cm.clicks || 0)
      const cv = parseFloat(cm.conversions || 0)
      return {
        id: r.campaign?.id, name: r.campaign?.name, channel: 'google_ads' as const,
        status: r.campaign?.status === 'ENABLED' ? 'ACTIVE' : 'PAUSED',
        objective: r.campaign?.advertising_channel_type || 'SEARCH',
        budget: parseInt(r.campaign_budget?.amount_micros || 0) / 1_000_000,
        budgetType: 'daily' as const,
        spend: cs, reach: ci, impressions: ci, clicks: cc,
        ctr: parseFloat(cm.ctr || 0) * 100,
        cpm: parseFloat(cm.average_cpm || 0) / 1_000_000,
        cpc: cc > 0 ? parseFloat((cs / cc).toFixed(2)) : 0,
        conversions: Math.round(cv),
        conversionRate: cc > 0 ? parseFloat(((cv / cc) * 100).toFixed(2)) : 0,
        roas: spend > 0 ? parseFloat((revenue / spend).toFixed(2)) : 0,
        startDate: new Date().toISOString().split('T')[0],
      }
    })

    return NextResponse.json({
      channel: 'google_ads', demo: false, spend,
      reach: impressions, impressions, clicks,
      ctr: parseFloat(((clicks / impressions) * 100).toFixed(2)),
      cpm: parseFloat((m.average_cpm || 0)) / 1_000_000,
      conversions: Math.round(conversions),
      roas: spend > 0 ? parseFloat((revenue / spend).toFixed(2)) : 0,
      campaigns, series: [],
    })
  } catch (err: any) {
    console.error('[Google Ads]', err.message)
    return NextResponse.json({ ...makeDemoChannel('google_ads'), demo: true, error: err.message })
  }
}
