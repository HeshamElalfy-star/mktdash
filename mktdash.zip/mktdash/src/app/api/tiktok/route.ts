import { NextResponse } from 'next/server'
import { makeDemoChannel } from '@/lib/demo'

const TOKEN       = process.env.TIKTOK_ACCESS_TOKEN
const APP_ID      = process.env.TIKTOK_APP_ID
const ADVERTISER  = process.env.TIKTOK_ADVERTISER_ID
const BASE        = 'https://business-api.tiktok.com/open_api/v1.3'

function isConfigured() {
  return TOKEN && TOKEN !== 'your_tiktok_access_token' &&
         ADVERTISER && ADVERTISER !== 'your_advertiser_id'
}

async function ttGet(path: string, params: Record<string, string> = {}) {
  const url = new URL(`${BASE}${path}`)
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v))
  const res = await fetch(url.toString(), {
    headers: { 'Access-Token': TOKEN!, 'Content-Type': 'application/json' },
    next: { revalidate: 25 },
  })
  if (!res.ok) throw new Error(`TikTok ${res.status}: ${await res.text()}`)
  const json = await res.json()
  if (json.code !== 0) throw new Error(`TikTok API error: ${json.message}`)
  return json.data
}

function todayStr() { return new Date().toISOString().split('T')[0] }
function weekAgoStr() {
  const d = new Date(); d.setDate(d.getDate() - 7)
  return d.toISOString().split('T')[0]
}

export async function GET() {
  if (!isConfigured()) {
    return NextResponse.json(makeDemoChannel('tiktok'))
  }

  try {
    const metrics = 'spend,reach,impressions,clicks,ctr,cpm,conversion,real_time_conversion'
    const today   = todayStr()
    const weekAgo = weekAgoStr()

    const [accountIns, campaigns] = await Promise.all([
      ttGet('/report/integrated/get/', {
        advertiser_id: ADVERTISER!,
        report_type:  'BASIC',
        data_level:   'AUCTION_ADVERTISER',
        dimensions:   JSON.stringify(['stat_time_day']),
        metrics:      JSON.stringify(metrics.split(',')),
        start_date:   today,
        end_date:     today,
        page_size:    '10',
      }),
      ttGet('/campaign/get/', {
        advertiser_id:  ADVERTISER!,
        fields:         JSON.stringify(['campaign_name','status','objective_type','budget','budget_mode']),
        primary_status: 'STATUS_ALL',
        page_size:      '20',
      }),
    ])

    const rows = accountIns?.list || []
    const totals = rows.reduce((acc: any, r: any) => {
      const m = r.metrics || {}
      acc.spend       += parseFloat(m.spend || 0)
      acc.reach       += parseInt(m.reach || 0)
      acc.impressions += parseInt(m.impressions || 0)
      acc.clicks      += parseInt(m.clicks || 0)
      acc.conversions += parseInt(m.conversion || m.real_time_conversion || 0)
      return acc
    }, { spend: 0, reach: 0, impressions: 0, clicks: 0, conversions: 0 })

    const cmpList = (campaigns?.list || []).map((c: any) => {
      const spend = parseFloat(c.metrics?.spend || 0)
      const impr  = parseInt(c.metrics?.impressions || 0)
      const clk   = parseInt(c.metrics?.clicks || 0)
      const conv  = parseInt(c.metrics?.conversion || 0)
      return {
        id: c.campaign_id, name: c.campaign_name, channel: 'tiktok' as const,
        status: c.status === 'CAMPAIGN_STATUS_ENABLE' ? 'ACTIVE' : 'PAUSED',
        objective: c.objective_type || 'REACH',
        budget: parseFloat(c.budget || 0),
        budgetType: c.budget_mode === 'BUDGET_MODE_DAY' ? 'daily' : 'lifetime' as any,
        spend, reach: impr, impressions: impr, clicks: clk,
        ctr: impr > 0 ? parseFloat(((clk / impr) * 100).toFixed(2)) : 0,
        cpm: impr > 0 ? parseFloat(((spend / impr) * 1000).toFixed(2)) : 0,
        cpc: clk > 0  ? parseFloat((spend / clk).toFixed(2)) : 0,
        conversions: conv,
        conversionRate: clk > 0 ? parseFloat(((conv / clk) * 100).toFixed(2)) : 0,
        roas: spend > 0 ? parseFloat(((conv * 50) / spend).toFixed(2)) : 0,
        startDate: new Date().toISOString().split('T')[0],
      }
    })

    return NextResponse.json({
      channel: 'tiktok', demo: false,
      ...totals,
      ctr: totals.impressions > 0 ? parseFloat(((totals.clicks / totals.impressions) * 100).toFixed(2)) : 0,
      cpm: totals.impressions > 0 ? parseFloat(((totals.spend / totals.impressions) * 1000).toFixed(2)) : 0,
      roas: totals.spend > 0 ? parseFloat(((totals.conversions * 50) / totals.spend).toFixed(2)) : 0,
      campaigns: cmpList, series: [],
    })
  } catch (err: any) {
    console.error('[TikTok]', err.message)
    return NextResponse.json({ ...makeDemoChannel('tiktok'), demo: true, error: err.message })
  }
}
