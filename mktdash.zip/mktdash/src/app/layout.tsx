import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'MktDash — Marketing Dashboard',
  description: 'داش بورد تسويق لايف — Facebook · Instagram · Google Ads · TikTok',
  icons: { icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><rect width='32' height='32' rx='8' fill='%23f5a623'/><text x='16' y='22' text-anchor='middle' font-size='18' font-weight='bold' fill='black'>M</text></svg>" },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  )
}
