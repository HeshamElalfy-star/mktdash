'use client'
import { useState } from 'react'
import { useDashboard } from '@/hooks/useDashboard'
import { KpiCard }        from '@/components/ui/KpiCard'
import { Sidebar }        from '@/components/ui/Sidebar'
import { ChannelCard }    from '@/components/ui/ChannelCard'
import { SettingsPanel }  from '@/components/ui/SettingsPanel'
import { CampaignsTable } from '@/components/tables/CampaignsTable'
import { BudgetTable }    from '@/components/tables/BudgetTable'
import { ReportTable }    from '@/components/tables/ReportTable'
import { MultiLineChart } from '@/components/charts/MultiLineChart'
import { SpendDonut }     from '@/components/charts/SpendDonut'
import { BarComparison }  from '@/components/charts/BarComparison'
import { fmtCur, fmtNum, fmtPct, fmtRoas } from '@/lib/formatters'

export default function Page() {
  const { data, loading, error, lastUpdated, paused, refresh, togglePause } = useDashboard()
  const [page, setPage] = useState('overview')
  const [chartMetric, setChartMetric] = useState<'spend'|'reach'|'clicks'|'conversions'>('reach')

  const isDemo  = data?.channels?.some(c => c.demo) ?? true
  const chs     = data?.channels || []
  const allCampaigns = chs.flatMap(c => c.campaigns)

  const G = ({ cols = 4, children }: { cols?: number; children: React.ReactNode }) => (
    <div style={{ display: 'grid', gridTemplateColumns: `repeat(${cols}, minmax(0,1fr))`, gap: 12, marginBottom: 20 }}>
      {children}
    </div>
  )

  const Section = ({ children }: { children: React.ReactNode }) => (
    <div style={{ marginBottom: 20 }}>{children}</div>
  )

  /* ── Overview Page ── */
  const PageOverview = () => (
    <>
      {/* KPIs */}
      <G cols={4}>
        <KpiCard label="إجمالي الإنفاق"    value={data ? fmtCur(data.totalSpend)           : '—'} sub={data ? `${chs.length} قنوات`       : undefined} accent="#f5a623" accentDim="rgba(245,166,35,.08)"  icon="💰" loading={loading} />
        <KpiCard label="إجمالي الوصول"     value={data ? fmtNum(data.totalReach)            : '—'} sub={data ? `${fmtNum(data.totalImpressions)} ظهور` : undefined} accent="#3b82f6" accentDim="rgba(59,130,246,.08)"  icon="👁️" loading={loading} />
        <KpiCard label="إجمالي التحويلات"  value={data ? fmtNum(data.totalConversions)      : '—'} sub={data ? `${fmtPct(data.avgCtr)} CTR`   : undefined} accent="#22c55e" accentDim="rgba(34,197,94,.08)"   icon="🎯" loading={loading} />
        <KpiCard label="متوسط ROAS"         value={data ? fmtRoas(data.avgRoas)              : '—'} sub={data ? `${fmtNum(data.totalClicks)} نقرة` : undefined} accent="#a78bfa" accentDim="rgba(167,139,250,.08)" icon="📈" loading={loading} />
      </G>

      {/* Channel cards */}
      <G cols={2}>
        {loading ? [1,2,3,4].map(i => (
          <div key={i} className="card" style={{ padding: '1rem', minHeight: 120 }}>
            <div className="shimmer" style={{ height: 14, width: '40%', marginBottom: 12 }} />
            <div className="shimmer" style={{ height: 20, width: '60%', marginBottom: 8 }} />
            <div className="shimmer" style={{ height: 10, width: '30%' }} />
          </div>
        )) : chs.map(ch => <ChannelCard key={ch.channel} ch={ch} />)}
      </G>

      {/* Charts row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 16, marginBottom: 20 }}>
        <div className="card" style={{ padding: '1.25rem 1.5rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div className="sec-label" style={{ marginBottom: 0 }}>الأداء عبر الزمن — 7 أيام</div>
            <div className="tab-bar">
              {(['reach','spend','clicks','conversions'] as const).map(m => (
                <button key={m} className={`tab-btn ${chartMetric === m ? 'active' : ''}`}
                  onClick={() => setChartMetric(m)}
                  style={{ padding: '4px 10px', fontSize: 11 }}>
                  {{reach:'وصول',spend:'إنفاق',clicks:'نقرات',conversions:'تحويلات'}[m]}
                </button>
              ))}
            </div>
          </div>
          {!loading && chs.length > 0 && <MultiLineChart channels={chs} metric={chartMetric} />}
        </div>

        <div className="card" style={{ padding: '1.25rem 1.5rem' }}>
          <div className="sec-label">توزيع الإنفاق</div>
          {!loading && chs.length > 0 && <SpendDonut channels={chs} />}
        </div>
      </div>

      {/* Bar comparison */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
        <div className="card" style={{ padding: '1.25rem 1.5rem' }}>
          <BarComparison channels={chs} metric="ctr" label="مقارنة CTR بين القنوات" />
        </div>
        <div className="card" style={{ padding: '1.25rem 1.5rem' }}>
          <BarComparison channels={chs} metric="roas" label="مقارنة ROAS بين القنوات" />
        </div>
      </div>
    </>
  )

  /* ── Campaigns Page ── */
  const PageCampaigns = () => (
    <Section>
      <G cols={3}>
        <KpiCard label="إجمالي الحملات"     value={`${allCampaigns.length}`}                                  accent="#3b82f6" accentDim="rgba(59,130,246,.08)"  icon="📋" loading={loading} />
        <KpiCard label="حملات نشطة"         value={`${allCampaigns.filter(c=>c.status==='ACTIVE').length}`}   accent="#22c55e" accentDim="rgba(34,197,94,.08)"   icon="✅" loading={loading} />
        <KpiCard label="حملات موقوفة"       value={`${allCampaigns.filter(c=>c.status==='PAUSED').length}`}   accent="#f59e0b" accentDim="rgba(245,158,11,.08)"  icon="⏸" loading={loading} />
      </G>
      <CampaignsTable campaigns={allCampaigns} title="كل الحملات" />
    </Section>
  )

  /* ── Performance Page ── */
  const PagePerformance = () => (
    <>
      <G cols={4}>
        <KpiCard label="إجمالي النقرات"    value={data ? fmtNum(data.totalClicks)       : '—'} accent="#3b82f6" accentDim="rgba(59,130,246,.08)"  icon="🖱️" loading={loading} />
        <KpiCard label="متوسط CTR"          value={data ? fmtPct(data.avgCtr)            : '—'} accent="#22c55e" accentDim="rgba(34,197,94,.08)"   icon="📊" loading={loading} />
        <KpiCard label="إجمالي الظهورات"   value={data ? fmtNum(data.totalImpressions)  : '—'} accent="#f59e0b" accentDim="rgba(245,158,11,.08)"  icon="👁️" loading={loading} />
        <KpiCard label="متوسط ROAS"         value={data ? fmtRoas(data.avgRoas)          : '—'} accent="#a78bfa" accentDim="rgba(167,139,250,.08)" icon="💹" loading={loading} />
      </G>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
        <div className="card" style={{ padding: '1.25rem 1.5rem' }}>
          <BarComparison channels={chs} metric="conversions" label="التحويلات لكل قناة" />
        </div>
        <div className="card" style={{ padding: '1.25rem 1.5rem' }}>
          <BarComparison channels={chs} metric="cpm" label="CPM لكل قناة" />
        </div>
      </div>
      <div className="card" style={{ padding: '1.25rem 1.5rem', marginBottom: 20 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div className="sec-label" style={{ marginBottom: 0 }}>تحليل الأداء عبر الزمن</div>
        </div>
        {!loading && chs.length > 0 && <MultiLineChart channels={chs} metric="conversions" />}
      </div>
      {chs.map(ch => (
        <div key={ch.channel} style={{ marginBottom: 16 }}>
          <CampaignsTable campaigns={ch.campaigns} title={`${ch.channel === 'facebook' ? 'Facebook' : ch.channel === 'instagram' ? 'Instagram' : ch.channel === 'google_ads' ? 'Google Ads' : 'TikTok'} — الحملات`} />
        </div>
      ))}
    </>
  )

  /* ── Budget Page ── */
  const PageBudget = () => (
    <>
      <G cols={3}>
        <KpiCard label="إجمالي الميزانية"  value={data ? fmtCur(data.budget?.reduce((s:number,b:any)=>s+b.allocated,0)||0) : '—'} accent="#f5a623" accentDim="rgba(245,166,35,.08)"  icon="💼" loading={loading} />
        <KpiCard label="إجمالي الإنفاق"    value={data ? fmtCur(data.totalSpend)  : '—'} accent="#ef4444" accentDim="rgba(239,68,68,.08)"    icon="💸" loading={loading} />
        <KpiCard label="الميزانية المتبقية" value={data ? fmtCur((data.budget?.reduce((s:number,b:any)=>s+b.allocated,0)||0) - data.totalSpend) : '—'} accent="#22c55e" accentDim="rgba(34,197,94,.08)"   icon="🏦" loading={loading} />
      </G>
      {data?.budget && <BudgetTable items={data.budget} />}
    </>
  )

  /* ── Reports Page ── */
  const PageReports = () => (
    <>
      <G cols={4}>
        <KpiCard label="إجمالي الإنفاق"   value={data ? fmtCur(data.totalSpend)        : '—'} accent="#f5a623" accentDim="rgba(245,166,35,.08)"  icon="💰" loading={loading} />
        <KpiCard label="إجمالي الوصول"    value={data ? fmtNum(data.totalReach)         : '—'} accent="#3b82f6" accentDim="rgba(59,130,246,.08)"  icon="👥" loading={loading} />
        <KpiCard label="إجمالي التحويلات" value={data ? fmtNum(data.totalConversions)   : '—'} accent="#22c55e" accentDim="rgba(34,197,94,.08)"   icon="🎯" loading={loading} />
        <KpiCard label="متوسط ROAS"        value={data ? fmtRoas(data.avgRoas)           : '—'} accent="#a78bfa" accentDim="rgba(167,139,250,.08)" icon="📈" loading={loading} />
      </G>
      {chs.length > 0 && <ReportTable channels={chs} />}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginTop: 16 }}>
        <div className="card" style={{ padding: '1.25rem 1.5rem' }}>
          <div className="sec-label">اتجاه الإنفاق</div>
          {!loading && chs.length > 0 && <MultiLineChart channels={chs} metric="spend" />}
        </div>
        <div className="card" style={{ padding: '1.25rem 1.5rem' }}>
          <div className="sec-label">اتجاه التحويلات</div>
          {!loading && chs.length > 0 && <MultiLineChart channels={chs} metric="conversions" />}
        </div>
      </div>
    </>
  )

  return (
    <div className="layout">
      <Sidebar active={page} onNav={setPage} demo={isDemo} lastUpdated={lastUpdated}
        paused={paused} onTogglePause={togglePause} onRefresh={refresh} />

      <main className="main-area">
        {/* Page header */}
        <div style={{ marginBottom: 24, display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <div>
            <h1 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text)', letterSpacing: '-0.02em' }}>
              {{ overview:'نظرة عامة', campaigns:'الحملات', performance:'الأداء', budget:'الميزانية', reports:'التقارير', settings:'الإعدادات' }[page]}
            </h1>
            <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 3 }}>
              Facebook Ads · Instagram · Google Ads · TikTok
              {isDemo && <span style={{ marginRight: 10, color: 'var(--amber)' }}>— Demo Mode</span>}
            </div>
          </div>
          {error && (
            <div style={{ background: 'rgba(244,63,94,.1)', border: '1px solid rgba(244,63,94,.25)', borderRadius: 8, padding: '8px 14px', fontSize: 12, color: 'var(--red)' }}>
              ⚠ {error}
            </div>
          )}
        </div>

        {page === 'overview'     && <PageOverview />}
        {page === 'campaigns'    && <PageCampaigns />}
        {page === 'performance'  && <PagePerformance />}
        {page === 'budget'       && <PageBudget />}
        {page === 'reports'      && <PageReports />}
        {page === 'settings'     && <SettingsPanel />}
      </main>
    </div>
  )
}
