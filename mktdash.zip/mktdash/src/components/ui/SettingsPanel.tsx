'use client'
import { useState } from 'react'

interface Field { key: string; label: string; placeholder: string; help: string }
interface Section { id: string; title: string; icon: string; color: string; url: string; fields: Field[] }

const SECTIONS: Section[] = [
  {
    id: 'facebook', title: 'Facebook & Instagram Ads', icon: '📘', color: '#3b82f6',
    url: 'https://developers.facebook.com/apps',
    fields: [
      { key: 'FACEBOOK_ACCESS_TOKEN',  label: 'Access Token',    placeholder: 'EAAxxxxx...', help: 'Long-lived token من Graph API Explorer' },
      { key: 'FACEBOOK_AD_ACCOUNT_ID', label: 'Ad Account ID',   placeholder: 'act_123456789', help: 'من Business Settings → Ad Accounts' },
      { key: 'FACEBOOK_APP_ID',        label: 'App ID',           placeholder: '123456789', help: 'من صفحة الـ App' },
      { key: 'FACEBOOK_APP_SECRET',    label: 'App Secret',       placeholder: 'abc123...', help: 'من App Settings → Basic' },
    ],
  },
  {
    id: 'google', title: 'Google Ads', icon: '🔍', color: '#f59e0b',
    url: 'https://console.cloud.google.com',
    fields: [
      { key: 'GOOGLE_ADS_DEVELOPER_TOKEN', label: 'Developer Token',  placeholder: 'ABCDEF...', help: 'من Google Ads API Center' },
      { key: 'GOOGLE_ADS_CLIENT_ID',       label: 'Client ID',         placeholder: 'xxx.apps.googleusercontent.com', help: 'OAuth 2.0 Client' },
      { key: 'GOOGLE_ADS_CLIENT_SECRET',   label: 'Client Secret',     placeholder: 'GOCSPX-...', help: 'OAuth 2.0 Secret' },
      { key: 'GOOGLE_ADS_REFRESH_TOKEN',   label: 'Refresh Token',     placeholder: '1//xxx...', help: 'بعد OAuth authorization' },
      { key: 'GOOGLE_ADS_CUSTOMER_ID',     label: 'Customer ID',       placeholder: '1234567890', help: 'بدون dashes' },
    ],
  },
  {
    id: 'tiktok', title: 'TikTok Ads', icon: '🎵', color: '#a78bfa',
    url: 'https://ads.tiktok.com/marketing_api/apps',
    fields: [
      { key: 'TIKTOK_ACCESS_TOKEN',   label: 'Access Token',    placeholder: 'xxx...', help: 'من TikTok Marketing API' },
      { key: 'TIKTOK_APP_ID',         label: 'App ID',          placeholder: '123456', help: 'من App management' },
      { key: 'TIKTOK_ADVERTISER_ID',  label: 'Advertiser ID',   placeholder: '7123456789', help: 'من Ads Manager URL' },
    ],
  },
]

export function SettingsPanel() {
  const [copied, setCopied] = useState(false)

  const envContent = `# Facebook / Instagram
FACEBOOK_ACCESS_TOKEN=
FACEBOOK_AD_ACCOUNT_ID=
FACEBOOK_APP_ID=
FACEBOOK_APP_SECRET=

# Google Ads
GOOGLE_ADS_DEVELOPER_TOKEN=
GOOGLE_ADS_CLIENT_ID=
GOOGLE_ADS_CLIENT_SECRET=
GOOGLE_ADS_REFRESH_TOKEN=
GOOGLE_ADS_CUSTOMER_ID=

# TikTok
TIKTOK_ACCESS_TOKEN=
TIKTOK_APP_ID=
TIKTOK_ADVERTISER_ID=

# Settings
NEXT_PUBLIC_REFRESH_MS=30000
NEXT_PUBLIC_CURRENCY=ج.م`

  const copy = () => {
    navigator.clipboard.writeText(envContent)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {/* Intro */}
      <div className="card" style={{ padding: '1.25rem 1.5rem', background: 'var(--amber-dim)', borderColor: 'rgba(245,166,35,.25)' }}>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
          <span style={{ fontSize: 20 }}>⚡</span>
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--amber)', marginBottom: 6 }}>
              الداش بورد جاهز — بس محتاج API Keys
            </div>
            <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.7 }}>
              حالياً شغال بـ Demo Data. عشان توصل لبياناتك الحقيقية، أضف الـ API Keys في ملف
              <code style={{ background: 'var(--bg-3)', padding: '1px 6px', borderRadius: 4, fontSize: 12, margin: '0 4px', color: 'var(--amber)' }}>.env.local</code>
              في جذر المشروع.
            </div>
          </div>
        </div>
      </div>

      {/* .env template */}
      <div className="card" style={{ padding: '1.25rem 1.5rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <div className="sec-label" style={{ marginBottom: 0 }}>قالب .env.local</div>
          <button onClick={copy} style={{ background: copied ? 'var(--green-dim)' : 'var(--bg-3)', border: `1px solid ${copied ? 'rgba(34,197,94,.3)' : 'var(--border)'}`, color: copied ? 'var(--green)' : 'var(--text-2)', borderRadius: 8, padding: '5px 14px', fontSize: 12, cursor: 'pointer', fontFamily: 'var(--font-display)' }}>
            {copied ? '✓ تم النسخ' : '↳ نسخ القالب'}
          </button>
        </div>
        <pre style={{ background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: 8, padding: '14px', fontSize: 11, color: 'var(--text-2)', fontFamily: 'var(--font-mono)', lineHeight: 1.8, overflow: 'auto' }}>
          {envContent}
        </pre>
      </div>

      {/* Per-platform guide */}
      {SECTIONS.map(sec => (
        <div key={sec.id} className="card" style={{ borderRight: `2px solid ${sec.color}` }}>
          <div style={{ padding: '1rem 1.5rem', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 18 }}>{sec.icon}</span>
              <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>{sec.title}</span>
            </div>
            <a href={sec.url} target="_blank" rel="noopener noreferrer" style={{ fontSize: 11, color: sec.color, textDecoration: 'none', background: `rgba(${sec.color.slice(1)},0.1)`, padding: '4px 10px', borderRadius: 20 }}>
              افتح الـ Console ↗
            </a>
          </div>
          <div style={{ padding: '1rem 1.5rem', display: 'flex', flexDirection: 'column', gap: 10 }}>
            {sec.fields.map(f => (
              <div key={f.key} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
                <code style={{ background: 'var(--bg-3)', border: '1px solid var(--border)', color: sec.color, padding: '4px 8px', borderRadius: 6, fontSize: 11, fontFamily: 'var(--font-mono)', whiteSpace: 'nowrap', minWidth: 220 }}>
                  {f.key}
                </code>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--text)' }}>{f.label}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>{f.help}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
