'use client'

interface Props {
  active: string
  onNav: (page: string) => void
  demo: boolean
  lastUpdated: Date | null
  paused: boolean
  onTogglePause: () => void
  onRefresh: () => void
}

const NAV = [
  { id: 'overview',   label: 'نظرة عامة',    icon: '◈' },
  { id: 'campaigns',  label: 'الحملات',       icon: '◉' },
  { id: 'performance',label: 'الأداء',        icon: '◇' },
  { id: 'budget',     label: 'الميزانية',     icon: '◎' },
  { id: 'reports',    label: 'التقارير',      icon: '▤' },
  { id: 'settings',   label: 'الإعدادات',     icon: '⊙' },
]

export function Sidebar({ active, onNav, demo, lastUpdated, paused, onTogglePause, onRefresh }: Props) {
  const fmtTime = (d: Date | null) => {
    if (!d) return '—'
    return d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  }

  return (
    <nav className="sidebar">
      {/* Logo */}
      <div style={{ padding: '24px 20px 20px', borderBottom: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 32, height: 32, background: 'var(--amber)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, color: '#000', fontWeight: 700 }}>M</div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text)', letterSpacing: '-0.01em' }}>MktDash</div>
            <div style={{ fontSize: 10, color: 'var(--text-3)', letterSpacing: '0.06em' }}>MARKETING</div>
          </div>
        </div>
      </div>

      {/* Live status */}
      <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
            <div className="live-dot" style={{ background: paused ? 'var(--amber)' : 'var(--green)' }} />
            <span style={{ fontSize: 11, fontWeight: 600, color: paused ? 'var(--amber)' : 'var(--green)', letterSpacing: '0.06em' }}>
              {paused ? 'موقوف' : 'LIVE'}
            </span>
          </div>
          {demo && <span className="badge badge-amber" style={{ fontSize: 9 }}>DEMO</span>}
        </div>
        <div style={{ fontSize: 10, color: 'var(--text-3)', marginBottom: 10, fontFamily: 'var(--font-mono)' }}>
          {fmtTime(lastUpdated)}
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button onClick={onRefresh} style={{ flex: 1, background: 'var(--bg-3)', border: '1px solid var(--border)', color: 'var(--text-2)', borderRadius: 7, padding: '5px 0', fontSize: 11, cursor: 'pointer', fontFamily: 'var(--font-display)' }}>↻ تحديث</button>
          <button onClick={onTogglePause} style={{ flex: 1, background: paused ? 'var(--amber-dim)' : 'var(--bg-3)', border: `1px solid ${paused ? 'rgba(245,166,35,.3)' : 'var(--border)'}`, color: paused ? 'var(--amber)' : 'var(--text-2)', borderRadius: 7, padding: '5px 0', fontSize: 11, cursor: 'pointer', fontFamily: 'var(--font-display)' }}>
            {paused ? '▶ استئناف' : '⏸ إيقاف'}
          </button>
        </div>
      </div>

      {/* Nav */}
      <div style={{ padding: '12px 12px', flex: 1 }}>
        {NAV.map(n => (
          <button key={n.id} onClick={() => onNav(n.id)}
            style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 10,
              padding: '9px 10px', borderRadius: 9, border: 'none', cursor: 'pointer',
              fontFamily: 'var(--font-display)', fontSize: 13, fontWeight: 500,
              background: active === n.id ? 'var(--bg-3)' : 'transparent',
              color: active === n.id ? 'var(--text)' : 'var(--text-3)',
              marginBottom: 2,
              transition: 'all 0.15s',
              borderRight: active === n.id ? '2px solid var(--amber)' : '2px solid transparent',
            }}>
            <span style={{ fontSize: 14, opacity: active === n.id ? 1 : 0.6 }}>{n.icon}</span>
            {n.label}
          </button>
        ))}
      </div>

      {/* Channels indicator */}
      <div style={{ padding: '14px 20px', borderTop: '1px solid var(--border)' }}>
        <div style={{ fontSize: 10, color: 'var(--text-3)', letterSpacing: '0.08em', marginBottom: 8, textTransform: 'uppercase' }}>القنوات</div>
        {[
          { label: 'Facebook', color: '#3b82f6' },
          { label: 'Instagram', color: '#f472b6' },
          { label: 'Google Ads', color: '#f59e0b' },
          { label: 'TikTok', color: '#a78bfa' },
        ].map(ch => (
          <div key={ch.label} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 5 }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: ch.color, boxShadow: `0 0 6px ${ch.color}` }} />
            <span style={{ fontSize: 11, color: 'var(--text-2)' }}>{ch.label}</span>
          </div>
        ))}
      </div>
    </nav>
  )
}
