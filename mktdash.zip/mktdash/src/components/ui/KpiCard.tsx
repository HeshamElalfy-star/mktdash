'use client'
import { useEffect, useRef } from 'react'

interface Props {
  label: string
  value: string
  sub?: string
  subDir?: 'up' | 'dn' | 'neu'
  accent: string
  accentDim: string
  icon: string
  demo?: boolean
  loading?: boolean
}

export function KpiCard({ label, value, sub, subDir = 'neu', accent, accentDim, icon, demo, loading }: Props) {
  const valRef  = useRef<HTMLDivElement>(null)
  const prevRef = useRef(value)

  useEffect(() => {
    if (prevRef.current !== value && valRef.current) {
      valRef.current.classList.remove('flash')
      void valRef.current.offsetWidth
      valRef.current.classList.add('flash')
      prevRef.current = value
    }
  }, [value])

  if (loading) return (
    <div className="card" style={{ padding: '1.25rem 1.5rem', minHeight: 110 }}>
      <div className="shimmer" style={{ height: 11, width: '50%', marginBottom: 14 }} />
      <div className="shimmer" style={{ height: 28, width: '70%', marginBottom: 10 }} />
      <div className="shimmer" style={{ height: 10, width: '35%' }} />
    </div>
  )

  return (
    <div className="card" style={{
      padding: '1.25rem 1.5rem',
      borderRight: `2px solid ${accent}`,
      background: `linear-gradient(135deg, ${accentDim} 0%, var(--bg-1) 60%)`,
    }}>
      {demo && (
        <span className="mono" style={{ position: 'absolute', top: 8, left: 10, fontSize: 9, color: 'var(--text-3)', letterSpacing: '0.08em' }}>
          DEMO
        </span>
      )}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 10 }}>
        <span style={{ fontSize: 15 }}>{icon}</span>
        <span style={{ fontSize: 11, color: 'var(--text-3)', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
          {label}
        </span>
      </div>
      <div ref={valRef} className="metric-val mono" style={{ color: 'var(--text)', marginBottom: 6 }}>
        {value}
      </div>
      {sub && (
        <div style={{ fontSize: 12, color: subDir === 'up' ? 'var(--green)' : subDir === 'dn' ? 'var(--red)' : 'var(--text-3)' }}>
          {subDir === 'up' ? '↑' : subDir === 'dn' ? '↓' : ''} {sub}
        </div>
      )}
    </div>
  )
}
