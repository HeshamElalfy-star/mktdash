'use client'
import { ChannelStats, CHANNELS } from '@/lib/types'
import { fmtCur, fmtNum, fmtPct, fmtRoas } from '@/lib/formatters'

const CH_COLOR: Record<string, string> = {
  facebook: '#3b82f6', instagram: '#f472b6', google_ads: '#f59e0b', tiktok: '#a78bfa',
}

export function ChannelCard({ ch }: { ch: ChannelStats }) {
  const meta  = CHANNELS.find(c => c.id === ch.channel)
  const color = CH_COLOR[ch.channel]

  const metrics = [
    { label: 'الإنفاق',     value: fmtCur(ch.spend) },
    { label: 'الوصول',      value: fmtNum(ch.reach) },
    { label: 'CTR',         value: fmtPct(ch.ctr) },
    { label: 'تحويلات',     value: fmtNum(ch.conversions) },
    { label: 'CPM',         value: fmtCur(ch.cpm) },
    { label: 'ROAS',        value: fmtRoas(ch.roas) },
  ]

  return (
    <div className="card" style={{ background: `linear-gradient(135deg, rgba(${hexToRgb(color)},0.06) 0%, var(--bg-1) 50%)` }}>
      {/* Header */}
      <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 18 }}>{meta?.icon}</span>
          <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)' }}>{meta?.label}</span>
          {ch.demo && <span className="badge badge-gray" style={{ fontSize: 9 }}>DEMO</span>}
        </div>
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: color, boxShadow: `0 0 8px ${color}` }} />
      </div>
      {/* Metrics grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', padding: '1rem 1.25rem', gap: 12 }}>
        {metrics.map(m => (
          <div key={m.label}>
            <div style={{ fontSize: 10, color: 'var(--text-3)', marginBottom: 3, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{m.label}</div>
            <div className="mono" style={{ fontSize: 15, fontWeight: 600, color: 'var(--text)' }}>{m.value}</div>
          </div>
        ))}
      </div>
      {/* Active campaigns count */}
      <div style={{ padding: '8px 1.25rem', borderTop: '1px solid var(--border)', fontSize: 11, color: 'var(--text-3)', display: 'flex', gap: 12 }}>
        <span>الحملات النشطة: <b style={{ color }}>{ch.campaigns.filter(c => c.status === 'ACTIVE').length}</b></span>
        <span>إجمالي الحملات: <b style={{ color: 'var(--text-2)' }}>{ch.campaigns.length}</b></span>
      </div>
    </div>
  )
}

function hexToRgb(hex: string): string {
  const r = parseInt(hex.slice(1, 3), 16)
  const g = parseInt(hex.slice(3, 5), 16)
  const b = parseInt(hex.slice(5, 7), 16)
  return `${r},${g},${b}`
}
