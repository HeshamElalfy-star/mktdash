'use client'
import { BudgetItem, CHANNELS } from '@/lib/types'
import { fmtCur } from '@/lib/formatters'

const CH_COLOR: Record<string, string> = {
  facebook: '#3b82f6', instagram: '#f472b6', google_ads: '#f59e0b', tiktok: '#a78bfa',
}

export function BudgetTable({ items }: { items: BudgetItem[] }) {
  const total      = items.reduce((s, i) => s + i.allocated, 0)
  const totalSpent = items.reduce((s, i) => s + i.spent, 0)

  return (
    <div className="card">
      <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div className="sec-label" style={{ marginBottom: 0 }}>الميزانية والإنفاق</div>
        <div style={{ fontSize: 12, color: 'var(--text-3)' }}>
          إجمالي: <span className="mono" style={{ color: 'var(--text)' }}>{fmtCur(totalSpent)}</span>
          <span style={{ color: 'var(--text-3)' }}> / {fmtCur(total)}</span>
        </div>
      </div>
      <div style={{ padding: '1rem 1.5rem' }}>
        {items.map(item => {
          const ch    = CHANNELS.find(c => c.id === item.channel)
          const color = CH_COLOR[item.channel]
          const pct   = Math.min(item.pctUsed, 100)
          const warn  = pct >= 90 ? 'var(--red)' : pct >= 70 ? 'var(--amber)' : color
          return (
            <div key={item.channel} style={{ marginBottom: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 15 }}>{ch?.icon}</span>
                  <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)' }}>{ch?.label}</span>
                  {pct >= 90 && <span className="badge badge-red" style={{ fontSize: 9 }}>تحذير</span>}
                  {pct >= 70 && pct < 90 && <span className="badge badge-amber" style={{ fontSize: 9 }}>قارب الانتهاء</span>}
                </div>
                <div style={{ textAlign: 'left', fontSize: 12 }}>
                  <span className="mono" style={{ color: warn, fontWeight: 600 }}>{fmtCur(item.spent)}</span>
                  <span style={{ color: 'var(--text-3)' }}> / {fmtCur(item.allocated)}</span>
                </div>
              </div>
              <div className="prog-track">
                <div className="prog-fill" style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${color}, ${warn})` }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 5, fontSize: 10, color: 'var(--text-3)' }}>
                <span>{pct.toFixed(1)}% مُستخدم</span>
                <span>متبقي: <span className="mono">{fmtCur(item.remaining)}</span></span>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
