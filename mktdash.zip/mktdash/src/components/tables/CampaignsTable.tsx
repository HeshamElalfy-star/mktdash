'use client'
import { useState, useMemo } from 'react'
import { Campaign, CHANNELS } from '@/lib/types'
import { fmtCur, fmtPct, fmtNum, fmtRoas, statusBadge, statusLabel, objectiveLabel } from '@/lib/formatters'

const CH_COLOR: Record<string, string> = {
  facebook: '#3b82f6', instagram: '#f472b6', google_ads: '#f59e0b', tiktok: '#a78bfa',
}

interface Props { campaigns: Campaign[]; title?: string }

type SortKey = 'name' | 'spend' | 'reach' | 'ctr' | 'conversions' | 'roas' | 'cpc'

export function CampaignsTable({ campaigns, title = 'الحملات' }: Props) {
  const [sortKey,  setSortKey]  = useState<SortKey>('spend')
  const [sortDir,  setSortDir]  = useState<1 | -1>(-1)
  const [filter,   setFilter]   = useState<string>('ALL')
  const [search,   setSearch]   = useState('')

  const headers: { key: SortKey; label: string }[] = [
    { key: 'name',        label: 'الحملة'    },
    { key: 'spend',       label: 'الإنفاق'   },
    { key: 'reach',       label: 'الوصول'    },
    { key: 'ctr',         label: 'CTR'       },
    { key: 'conversions', label: 'تحويلات'   },
    { key: 'cpc',         label: 'CPC'       },
    { key: 'roas',        label: 'ROAS'      },
  ]

  const sorted = useMemo(() => {
    let list = campaigns
    if (filter !== 'ALL') list = list.filter(c => c.channel === filter || c.status === filter)
    if (search) list = list.filter(c => c.name.includes(search))
    return [...list].sort((a, b) => {
      const av = a[sortKey as keyof Campaign] as number
      const bv = b[sortKey as keyof Campaign] as number
      return (av > bv ? 1 : av < bv ? -1 : 0) * sortDir
    })
  }, [campaigns, sortKey, sortDir, filter, search])

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 1 ? -1 : 1)
    else { setSortKey(key); setSortDir(-1) }
  }

  return (
    <div className="card">
      <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10 }}>
        <div className="sec-label" style={{ marginBottom: 0 }}>{title}</div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <input
            placeholder="بحث..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ background: 'var(--bg-3)', border: '1px solid var(--border)', color: 'var(--text)', borderRadius: 8, padding: '5px 10px', fontSize: 12, fontFamily: 'var(--font-display)', width: 140 }}
          />
          <select value={filter} onChange={e => setFilter(e.target.value)}
            style={{ background: 'var(--bg-3)', border: '1px solid var(--border)', color: 'var(--text)', borderRadius: 8, padding: '5px 10px', fontSize: 12, fontFamily: 'var(--font-display)', cursor: 'pointer' }}>
            <option value="ALL">كل القنوات</option>
            {CHANNELS.map(ch => <option key={ch.id} value={ch.id}>{ch.label}</option>)}
            <option value="ACTIVE">نشطة فقط</option>
            <option value="PAUSED">موقوفة</option>
          </select>
        </div>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>القناة</th>
              <th>الحالة</th>
              <th>الهدف</th>
              {headers.map(h => (
                <th key={h.key} onClick={() => toggleSort(h.key)} style={{ cursor: 'pointer', userSelect: 'none', whiteSpace: 'nowrap' }}>
                  {h.label} {sortKey === h.key ? (sortDir === -1 ? '↓' : '↑') : ''}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sorted.map(c => (
              <tr key={c.id}>
                <td>
                  <div style={{ width: 8, height: 8, borderRadius: '50%', background: CH_COLOR[c.channel], display: 'inline-block', marginLeft: 6, boxShadow: `0 0 6px ${CH_COLOR[c.channel]}` }} />
                  <span style={{ fontSize: 11, color: 'var(--text-2)' }}>{CHANNELS.find(ch => ch.id === c.channel)?.label}</span>
                </td>
                <td><span className={`badge ${statusBadge(c.status)}`}>{statusLabel(c.status)}</span></td>
                <td><span style={{ fontSize: 11, color: 'var(--text-2)' }}>{objectiveLabel(c.objective)}</span></td>
                <td style={{ fontWeight: 600 }}>{c.name}</td>
                <td className="mono">{fmtCur(c.spend)}</td>
                <td className="mono">{fmtNum(c.reach)}</td>
                <td className="mono" style={{ color: c.ctr >= 3 ? 'var(--green)' : c.ctr >= 1.5 ? 'var(--amber)' : 'var(--red)' }}>{fmtPct(c.ctr)}</td>
                <td className="mono">{fmtNum(c.conversions)}</td>
                <td className="mono">{fmtCur(c.cpc)}</td>
                <td className="mono" style={{ color: c.roas >= 3 ? 'var(--green)' : c.roas >= 2 ? 'var(--amber)' : 'var(--red)' }}>{fmtRoas(c.roas)}</td>
              </tr>
            ))}
            {sorted.length === 0 && (
              <tr><td colSpan={10} style={{ textAlign: 'center', color: 'var(--text-3)', padding: '2rem' }}>لا توجد حملات</td></tr>
            )}
          </tbody>
        </table>
      </div>
      <div style={{ padding: '10px 20px', borderTop: '1px solid var(--border)', fontSize: 11, color: 'var(--text-3)', display: 'flex', gap: 16 }}>
        <span>إجمالي الحملات: <b style={{ color: 'var(--text)' }}>{sorted.length}</b></span>
        <span>إجمالي الإنفاق: <b style={{ color: 'var(--text)' }} className="mono">{fmtCur(sorted.reduce((s, c) => s + c.spend, 0))}</b></span>
        <span>إجمالي التحويلات: <b style={{ color: 'var(--text)' }}>{sorted.reduce((s, c) => s + c.conversions, 0).toLocaleString()}</b></span>
      </div>
    </div>
  )
}
