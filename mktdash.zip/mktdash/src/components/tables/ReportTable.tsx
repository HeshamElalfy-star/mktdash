'use client'
import { useState } from 'react'
import { ChannelStats, CHANNELS } from '@/lib/types'
import { fmtCur, fmtPct, fmtNum, fmtRoas } from '@/lib/formatters'

const CH_COLOR: Record<string, string> = {
  facebook: '#3b82f6', instagram: '#f472b6', google_ads: '#f59e0b', tiktok: '#a78bfa',
}

export function ReportTable({ channels }: { channels: ChannelStats[] }) {
  const [period, setPeriod] = useState<'today' | '7d' | '30d'>('7d')

  const totals = {
    spend:       channels.reduce((s, c) => s + c.spend, 0),
    reach:       channels.reduce((s, c) => s + c.reach, 0),
    impressions: channels.reduce((s, c) => s + c.impressions, 0),
    clicks:      channels.reduce((s, c) => s + c.clicks, 0),
    conversions: channels.reduce((s, c) => s + c.conversions, 0),
  }

  const exportCSV = () => {
    const rows = [
      ['القناة', 'الإنفاق', 'الوصول', 'الظهورات', 'النقرات', 'CTR', 'CPM', 'التحويلات', 'ROAS'],
      ...channels.map(c => {
        const ch = CHANNELS.find(x => x.id === c.channel)
        return [ch?.label, c.spend.toFixed(2), c.reach, c.impressions, c.clicks, c.ctr.toFixed(2)+'%', c.cpm.toFixed(2), c.conversions, c.roas.toFixed(2)+'x']
      }),
      ['الإجمالي', totals.spend.toFixed(2), totals.reach, totals.impressions, totals.clicks, '', '', totals.conversions, ''],
    ]
    const csv = rows.map(r => r.join(',')).join('\n')
    const a = document.createElement('a')
    a.href = URL.createObjectURL(new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' }))
    a.download = `marketing_report_${new Date().toISOString().split('T')[0]}.csv`
    a.click()
  }

  return (
    <div className="card">
      <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10 }}>
        <div className="sec-label" style={{ marginBottom: 0 }}>تقرير الأداء الشامل</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <div className="tab-bar" style={{ padding: 2 }}>
            {[{k:'today',l:'اليوم'},{k:'7d',l:'7 أيام'},{k:'30d',l:'30 يوم'}].map(p => (
              <button key={p.k} className={`tab-btn ${period === p.k ? 'active' : ''}`} onClick={() => setPeriod(p.k as any)} style={{ padding: '4px 10px', fontSize: 11 }}>{p.l}</button>
            ))}
          </div>
          <button onClick={exportCSV} style={{ background: 'var(--amber-dim)', border: '1px solid rgba(245,166,35,.3)', color: 'var(--amber)', borderRadius: 8, padding: '5px 14px', fontSize: 12, cursor: 'pointer', fontFamily: 'var(--font-display)', fontWeight: 500 }}>
            ↓ تصدير CSV
          </button>
        </div>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>القناة</th>
              <th>الإنفاق</th>
              <th>الوصول</th>
              <th>الظهورات</th>
              <th>النقرات</th>
              <th>CTR</th>
              <th>CPM</th>
              <th>CPC</th>
              <th>التحويلات</th>
              <th>ROAS</th>
            </tr>
          </thead>
          <tbody>
            {channels.map(c => {
              const ch = CHANNELS.find(x => x.id === c.channel)
              const color = CH_COLOR[c.channel]
              return (
                <tr key={c.channel}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ width: 10, height: 10, borderRadius: 3, background: color }} />
                      <span style={{ fontWeight: 500 }}>{ch?.label}</span>
                      {c.demo && <span className="badge badge-gray" style={{ fontSize: 9 }}>DEMO</span>}
                    </div>
                  </td>
                  <td className="mono" style={{ fontWeight: 600, color }}>{fmtCur(c.spend)}</td>
                  <td className="mono">{fmtNum(c.reach)}</td>
                  <td className="mono">{fmtNum(c.impressions)}</td>
                  <td className="mono">{fmtNum(c.clicks)}</td>
                  <td className="mono" style={{ color: c.ctr >= 3 ? 'var(--green)' : c.ctr >= 1.5 ? 'var(--amber)' : 'var(--red)' }}>{fmtPct(c.ctr)}</td>
                  <td className="mono">{fmtCur(c.cpm)}</td>
                  <td className="mono">{fmtCur(c.impressions > 0 ? c.spend / c.clicks : 0)}</td>
                  <td className="mono" style={{ color: 'var(--green)' }}>{fmtNum(c.conversions)}</td>
                  <td className="mono" style={{ color: c.roas >= 3 ? 'var(--green)' : c.roas >= 2 ? 'var(--amber)' : 'var(--red)', fontWeight: 600 }}>{fmtRoas(c.roas)}</td>
                </tr>
              )
            })}
          </tbody>
          <tfoot>
            <tr style={{ borderTop: '1px solid var(--border-hi)' }}>
              <td style={{ fontWeight: 700, color: 'var(--text)' }}>الإجمالي</td>
              <td className="mono" style={{ fontWeight: 700, color: 'var(--amber)' }}>{fmtCur(totals.spend)}</td>
              <td className="mono" style={{ fontWeight: 600 }}>{fmtNum(totals.reach)}</td>
              <td className="mono" style={{ fontWeight: 600 }}>{fmtNum(totals.impressions)}</td>
              <td className="mono" style={{ fontWeight: 600 }}>{fmtNum(totals.clicks)}</td>
              <td className="mono">{fmtPct(totals.impressions > 0 ? (totals.clicks / totals.impressions) * 100 : 0)}</td>
              <td>—</td>
              <td>—</td>
              <td className="mono" style={{ fontWeight: 700, color: 'var(--green)' }}>{fmtNum(totals.conversions)}</td>
              <td>—</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  )
}
