'use client'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { ChannelStats } from '@/lib/types'

const CH_COLOR: Record<string, string> = {
  facebook: '#3b82f6', instagram: '#f472b6',
  google_ads: '#f59e0b', tiktok: '#a78bfa',
}
const CH_LABEL: Record<string, string> = {
  facebook: 'Facebook', instagram: 'Instagram',
  google_ads: 'Google Ads', tiktok: 'TikTok',
}

interface Props {
  channels: ChannelStats[]
  metric: 'spend' | 'reach' | 'clicks' | 'conversions'
}

export function MultiLineChart({ channels, metric }: Props) {
  // Merge series by date
  const dateMap: Record<string, any> = {}
  channels.forEach(ch => {
    ch.series?.forEach(s => {
      if (!dateMap[s.date]) dateMap[s.date] = { date: s.date }
      dateMap[s.date][ch.channel] = s[metric]
    })
  })
  const data = Object.values(dateMap)

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.length) return null
    return (
      <div style={{ background: 'var(--bg-2)', border: '1px solid var(--border-hi)', borderRadius: 10, padding: '12px 16px', fontSize: 12 }}>
        <div style={{ color: 'var(--text-3)', marginBottom: 8, fontSize: 11 }}>{label}</div>
        {payload.map((p: any) => (
          <div key={p.dataKey} style={{ color: p.color, marginBottom: 4, display: 'flex', justifyContent: 'space-between', gap: 20 }}>
            <span>{CH_LABEL[p.dataKey]}</span>
            <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 500 }}>{p.value?.toLocaleString()}</span>
          </div>
        ))}
      </div>
    )
  }

  return (
    <ResponsiveContainer width="100%" height={200}>
      <LineChart data={data} margin={{ top: 4, right: 4, left: -24, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
        <XAxis dataKey="date" tick={{ fill: 'var(--text-3)', fontSize: 10 }} tickLine={false} axisLine={false} />
        <YAxis tick={{ fill: 'var(--text-3)', fontSize: 10 }} tickLine={false} axisLine={false} tickFormatter={v => v >= 1000 ? (v/1000).toFixed(0)+'K' : v} />
        <Tooltip content={<CustomTooltip />} />
        {channels.map(ch => (
          <Line key={ch.channel} type="monotone" dataKey={ch.channel}
            stroke={CH_COLOR[ch.channel]} strokeWidth={2}
            dot={false} activeDot={{ r: 4, strokeWidth: 0 }}
            name={CH_LABEL[ch.channel]} />
        ))}
      </LineChart>
    </ResponsiveContainer>
  )
}
