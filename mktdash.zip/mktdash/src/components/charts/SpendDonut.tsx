'use client'
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts'
import { ChannelStats } from '@/lib/types'
import { fmtCur } from '@/lib/formatters'

const CH_COLOR: Record<string, string> = {
  facebook: '#3b82f6', instagram: '#f472b6',
  google_ads: '#f59e0b', tiktok: '#a78bfa',
}
const CH_LABEL: Record<string, string> = {
  facebook: 'Facebook', instagram: 'Instagram',
  google_ads: 'Google Ads', tiktok: 'TikTok',
}

export function SpendDonut({ channels }: { channels: ChannelStats[] }) {
  const data  = channels.map(ch => ({ name: CH_LABEL[ch.channel], value: ch.spend, channel: ch.channel }))
  const total = data.reduce((s, d) => s + d.value, 0)

  const CustomTooltip = ({ active, payload }: any) => {
    if (!active || !payload?.length) return null
    const d = payload[0]
    return (
      <div style={{ background: 'var(--bg-2)', border: '1px solid var(--border-hi)', borderRadius: 10, padding: '10px 14px', fontSize: 12 }}>
        <div style={{ color: CH_COLOR[d.payload.channel], fontWeight: 600, marginBottom: 4 }}>{d.name}</div>
        <div style={{ color: 'var(--text)', fontFamily: 'var(--font-mono)' }}>{fmtCur(d.value)}</div>
        <div style={{ color: 'var(--text-3)' }}>{((d.value / total) * 100).toFixed(1)}%</div>
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
      <ResponsiveContainer width={140} height={140}>
        <PieChart>
          <Pie data={data} cx="50%" cy="50%" innerRadius={44} outerRadius={62}
            dataKey="value" paddingAngle={3} startAngle={90} endAngle={-270}>
            {data.map(d => <Cell key={d.channel} fill={CH_COLOR[d.channel]} stroke="none" />)}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
        </PieChart>
      </ResponsiveContainer>
      <div style={{ flex: 1 }}>
        {data.map(d => (
          <div key={d.channel} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 9 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 8, height: 8, borderRadius: 2, background: CH_COLOR[d.channel] }} />
              <span style={{ fontSize: 12, color: 'var(--text-2)' }}>{d.name}</span>
            </div>
            <div style={{ textAlign: 'left' }}>
              <span className="mono" style={{ fontSize: 12, color: 'var(--text)' }}>{fmtCur(d.value)}</span>
              <span style={{ fontSize: 10, color: 'var(--text-3)', marginRight: 6 }}>{total > 0 ? ((d.value / total) * 100).toFixed(0) : 0}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
