'use client'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell, ResponsiveContainer } from 'recharts'
import { ChannelStats } from '@/lib/types'

const CH_COLOR: Record<string, string> = {
  facebook: '#3b82f6', instagram: '#f472b6',
  google_ads: '#f59e0b', tiktok: '#a78bfa',
}
const CH_LABEL: Record<string, string> = {
  facebook: 'FB', instagram: 'IG', google_ads: 'GA', tiktok: 'TT',
}

interface Props {
  channels: ChannelStats[]
  metric: 'ctr' | 'roas' | 'conversions' | 'cpm'
  label: string
}

export function BarComparison({ channels, metric, label }: Props) {
  const data = channels.map(ch => ({
    name: CH_LABEL[ch.channel],
    channel: ch.channel,
    value: ch[metric],
  }))

  const CustomTooltip = ({ active, payload }: any) => {
    if (!active || !payload?.length) return null
    const d = payload[0]
    return (
      <div style={{ background: 'var(--bg-2)', border: '1px solid var(--border-hi)', borderRadius: 10, padding: '10px 14px', fontSize: 12 }}>
        <div style={{ color: CH_COLOR[d.payload.channel], fontWeight: 600 }}>{d.payload.name}</div>
        <div className="mono" style={{ color: 'var(--text)', marginTop: 4 }}>{d.value?.toFixed(2)}</div>
      </div>
    )
  }

  return (
    <div>
      <div className="sec-label">{label}</div>
      <ResponsiveContainer width="100%" height={150}>
        <BarChart data={data} margin={{ top: 4, right: 4, left: -28, bottom: 0 }} barCategoryGap="30%">
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
          <XAxis dataKey="name" tick={{ fill: 'var(--text-3)', fontSize: 11 }} tickLine={false} axisLine={false} />
          <YAxis tick={{ fill: 'var(--text-3)', fontSize: 10 }} tickLine={false} axisLine={false} />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
          <Bar dataKey="value" radius={[4, 4, 0, 0]}>
            {data.map(d => <Cell key={d.channel} fill={CH_COLOR[d.channel]} fillOpacity={0.85} />)}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
