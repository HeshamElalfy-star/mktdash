// ─── Channel Types ─────────────────────────────────────────────
export type ChannelId = 'facebook' | 'instagram' | 'google_ads' | 'tiktok'

export interface ChannelMeta {
  id: ChannelId
  label: string
  icon: string
  color: string
  colorDim: string
}

export const CHANNELS: ChannelMeta[] = [
  { id: 'facebook',   label: 'Facebook Ads', icon: '📘', color: '#3b82f6', colorDim: 'rgba(59,130,246,.15)' },
  { id: 'instagram',  label: 'Instagram',    icon: '📸', color: '#f472b6', colorDim: 'rgba(244,114,182,.15)' },
  { id: 'google_ads', label: 'Google Ads',   icon: '🔍', color: '#f59e0b', colorDim: 'rgba(245,158,11,.15)'  },
  { id: 'tiktok',     label: 'TikTok',       icon: '🎵', color: '#a78bfa', colorDim: 'rgba(167,139,250,.15)' },
]

// ─── Campaign ──────────────────────────────────────────────────
export interface Campaign {
  id: string
  name: string
  channel: ChannelId
  status: 'ACTIVE' | 'PAUSED' | 'ARCHIVED' | 'ENDED'
  objective: string
  budget: number
  budgetType: 'daily' | 'lifetime'
  spend: number
  reach: number
  impressions: number
  clicks: number
  ctr: number
  cpm: number
  cpc: number
  conversions: number
  conversionRate: number
  roas: number
  startDate: string
  endDate?: string
}

// ─── Channel Stats ─────────────────────────────────────────────
export interface ChannelStats {
  channel: ChannelId
  demo: boolean
  spend: number
  reach: number
  impressions: number
  clicks: number
  ctr: number
  cpm: number
  conversions: number
  roas: number
  campaigns: Campaign[]
  // time-series for chart (last 7 days)
  series: DayStat[]
}

export interface DayStat {
  date: string      // "May 20"
  spend: number
  reach: number
  clicks: number
  conversions: number
}

// ─── Overview (all channels combined) ─────────────────────────
export interface OverviewData {
  totalSpend: number
  totalReach: number
  totalImpressions: number
  totalClicks: number
  avgCtr: number
  totalConversions: number
  avgRoas: number
  channels: ChannelStats[]
  updatedAt: string
}

// ─── Budget ────────────────────────────────────────────────────
export interface BudgetItem {
  channel: ChannelId
  allocated: number
  spent: number
  remaining: number
  pctUsed: number
}

// ─── Report ────────────────────────────────────────────────────
export interface ReportRow {
  date: string
  channel: ChannelId
  spend: number
  reach: number
  clicks: number
  ctr: number
  conversions: number
  roas: number
}
