import { ChannelStats, ChannelId, Campaign, DayStat, OverviewData } from './types'
import { format, subDays } from 'date-fns'

function rnd(min: number, max: number, decimals = 0) {
  const v = min + Math.random() * (max - min)
  return decimals > 0 ? parseFloat(v.toFixed(decimals)) : Math.round(v)
}

function makeSeries(days = 7): DayStat[] {
  return Array.from({ length: days }, (_, i) => {
    const d = subDays(new Date(), days - 1 - i)
    const spend = rnd(800, 3500)
    const reach  = rnd(8000, 40000)
    const clicks = rnd(200, 1200)
    return { date: format(d, 'MMM d'), spend, reach, clicks, conversions: rnd(10, 80) }
  })
}

function makeCampaigns(channel: ChannelId, n = 4): Campaign[] {
  const names: Record<ChannelId, string[]> = {
    facebook:   ['صيف النار', 'رمضان كريم', 'بداية المدارس', 'بلاك فرايدي'],
    instagram:  ['ريلز أسبوعي', 'ستوري إعلان', 'كولاب إنفلونسر', 'بروموشن منتج'],
    google_ads: ['بحث عام', 'شوبينج', 'ديسبلاي', 'يوتيوب أدز'],
    tiktok:     ['توب فيو', 'سبارك أدز', 'إن-فيد', 'براند تيك أوفر'],
  }
  const objectives = ['CONVERSIONS','REACH','TRAFFIC','AWARENESS','LEADS']
  return Array.from({ length: n }, (_, i) => {
    const spend = rnd(1200, 8000)
    const budget = spend + rnd(500, 4000)
    const impressions = rnd(20000, 200000)
    const clicks = rnd(400, 8000)
    const conversions = rnd(15, 200)
    const reach = rnd(8000, 80000)
    return {
      id: `${channel}-${i}`,
      name: names[channel][i] || `حملة ${i + 1}`,
      channel,
      status: i === 0 ? 'ACTIVE' : i === 1 ? 'ACTIVE' : i === 2 ? 'PAUSED' : 'ENDED',
      objective: objectives[i % objectives.length],
      budget,
      budgetType: i % 2 === 0 ? 'daily' : 'lifetime',
      spend,
      reach,
      impressions,
      clicks,
      ctr: parseFloat(((clicks / impressions) * 100).toFixed(2)),
      cpm: parseFloat(((spend / impressions) * 1000).toFixed(2)),
      cpc: parseFloat((spend / clicks).toFixed(2)),
      conversions,
      conversionRate: parseFloat(((conversions / clicks) * 100).toFixed(2)),
      roas: parseFloat((rnd(200, 600) / 100).toFixed(2)),
      startDate: format(subDays(new Date(), rnd(10, 60)), 'yyyy-MM-dd'),
      endDate: i > 1 ? format(subDays(new Date(), rnd(1, 9)), 'yyyy-MM-dd') : undefined,
    }
  })
}

export function makeDemoChannel(channel: ChannelId): ChannelStats {
  const campaigns = makeCampaigns(channel)
  const spend = campaigns.reduce((s, c) => s + c.spend, 0)
  const reach = campaigns.reduce((s, c) => s + c.reach, 0)
  const impressions = campaigns.reduce((s, c) => s + c.impressions, 0)
  const clicks = campaigns.reduce((s, c) => s + c.clicks, 0)
  const conversions = campaigns.reduce((s, c) => s + c.conversions, 0)
  return {
    channel, demo: true,
    spend, reach, impressions, clicks,
    ctr: parseFloat(((clicks / impressions) * 100).toFixed(2)),
    cpm: parseFloat(((spend / impressions) * 1000).toFixed(2)),
    conversions,
    roas: parseFloat((rnd(150, 450) / 100).toFixed(2)),
    campaigns,
    series: makeSeries(7),
  }
}

export function buildOverview(channels: ChannelStats[]): OverviewData {
  return {
    totalSpend:       channels.reduce((s, c) => s + c.spend, 0),
    totalReach:       channels.reduce((s, c) => s + c.reach, 0),
    totalImpressions: channels.reduce((s, c) => s + c.impressions, 0),
    totalClicks:      channels.reduce((s, c) => s + c.clicks, 0),
    avgCtr:           parseFloat((channels.reduce((s, c) => s + c.ctr, 0) / channels.length).toFixed(2)),
    totalConversions: channels.reduce((s, c) => s + c.conversions, 0),
    avgRoas:          parseFloat((channels.reduce((s, c) => s + c.roas, 0) / channels.length).toFixed(2)),
    channels,
    updatedAt: new Date().toISOString(),
  }
}

export function buildBudget(channels: ChannelStats[]) {
  const totalBudgets: Record<string, number> = {
    facebook: 15000, instagram: 8000, google_ads: 12000, tiktok: 6000,
  }
  return channels.map(ch => ({
    channel: ch.channel,
    allocated: totalBudgets[ch.channel] || 10000,
    spent: ch.spend,
    remaining: (totalBudgets[ch.channel] || 10000) - ch.spend,
    pctUsed: parseFloat(((ch.spend / (totalBudgets[ch.channel] || 10000)) * 100).toFixed(1)),
  }))
}
