export const CUR = process.env.NEXT_PUBLIC_CURRENCY || 'ج.م'

export function fmtNum(n: number, decimals = 0): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M'
  if (n >= 1_000)     return (n / 1_000).toFixed(1) + 'K'
  return n.toFixed(decimals)
}

export function fmtCur(n: number): string {
  return fmtNum(n) + ' ' + CUR
}

export function fmtPct(n: number): string {
  return n.toFixed(2) + '%'
}

export function fmtRoas(n: number): string {
  return n.toFixed(2) + 'x'
}

export function deltaClass(n: number): string {
  return n > 0 ? 'up' : n < 0 ? 'dn' : 'neu'
}

export function deltaArrow(n: number): string {
  return n > 0 ? '↑' : n < 0 ? '↓' : '—'
}

export function statusBadge(status: string): string {
  switch (status) {
    case 'ACTIVE':   return 'badge-green'
    case 'PAUSED':   return 'badge-amber'
    case 'ENDED':    return 'badge-gray'
    case 'ARCHIVED': return 'badge-gray'
    default:         return 'badge-gray'
  }
}

export function statusLabel(status: string): string {
  switch (status) {
    case 'ACTIVE':   return 'نشطة'
    case 'PAUSED':   return 'موقوفة'
    case 'ENDED':    return 'منتهية'
    case 'ARCHIVED': return 'مؤرشفة'
    default:         return status
  }
}

export function objectiveLabel(o: string): string {
  const m: Record<string, string> = {
    CONVERSIONS: 'تحويلات',
    REACH:       'وصول',
    TRAFFIC:     'زيارات',
    AWARENESS:   'وعي',
    LEADS:       'ليدز',
  }
  return m[o] || o
}
